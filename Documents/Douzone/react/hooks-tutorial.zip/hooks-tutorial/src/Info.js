import React, { useReducer, useState } from 'react';

const initData = {
  name: '',
  nickname: '',
};

const Info = () => {
  const [state, dispatch] = useReducer(함수, 초기값);

  dispatch({ type: change });
  //   const [form, setForm] = useState({
  //     name: '',
  //     nickname: '',
  //   });

  //   const onChange = (e) => {
  //     setForm({ ...form, [e.target.name]: e.target.value });
  //   };

  return (
    <div>
      <div>
        <input name="name" value={form.name} onChange={onChange} />
        <input name="nickname" value={form.nickname} onChange={onChange} />
      </div>
      <div>
        <div>
          <b>이름:</b>
          {form.name}
        </div>
        <div>
          <b>닉네임:</b>
          {form.nickname}
        </div>
        <input name="nickname" value="" onChange={onChange} />
      </div>
    </div>
  );
};
export default Info;
